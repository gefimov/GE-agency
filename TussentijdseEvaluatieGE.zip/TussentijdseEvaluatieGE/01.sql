USE TussentijdseEvaluatie1C;

SELECT Personen.Voornaam, Huisdieren.Naam FROM Baasje
INNER join Personen on Personen_id = Baasje.Personen_id

 
